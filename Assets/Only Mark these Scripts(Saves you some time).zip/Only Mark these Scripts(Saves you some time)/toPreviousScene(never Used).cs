﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using UnityEngine.SceneManagement;

//purpose of this script was to try and have a universal try again button and this script would recieve the previous scene's index from the script "savingSceneIndex" and then go to that scene.
//it would be linked on a button so the button had the index of the previous scene on it so it would go back to the level the user was previously on and try it again.
//couldnt get to work in time.

public class toPreviousScene : MonoBehaviour
{
  /*  public void UpdateIndex(int sceneIndex)
    {
        SceneManager.LoadScene(sceneIndex);
        Debug.Log(sceneIndex);
    }*/
}
