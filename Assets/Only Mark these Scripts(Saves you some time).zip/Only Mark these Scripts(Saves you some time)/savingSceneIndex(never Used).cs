﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine.SceneManagement;
using UnityEngine;

//puropse of this script was to send the index of the scene that the user failed to the script called "toPreviousScene" so that you could click a button to go retry the level you failed
//couldnt get it to work

public class savingSceneIndex : MonoBehaviour
{
/*
    private int sceneIndex;

    private toPreviousScene tryAgainScene;

    void Awake()
    {
        sceneIndex = SceneManager.GetActiveScene().buildIndex;
        tryAgainScene = GameObject.FindObjectOfType<toPreviousScene>();
    }

     void OnCollisionEnter2D (Collision2D other)
    {
        tryAgainScene.UpdateIndex (sceneIndex);
        DontDestroyOnLoad(this.gameObject);
    }
    */
}
